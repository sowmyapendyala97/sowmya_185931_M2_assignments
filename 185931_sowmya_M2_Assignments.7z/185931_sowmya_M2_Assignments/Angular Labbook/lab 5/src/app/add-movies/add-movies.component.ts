import { Component, OnInit } from '@angular/core';
import { Movie } from '../Movie';
import { MsService } from '../ms.service';

@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {
  movieList: any = [];
  movienamemsg:string;
  movie: Movie = new Movie();
  constructor(private movieservice:MsService) {
    this.movieservice.getmovieDetails().subscribe(data => this.movieList = data);
   }

  ngOnInit() {
  }
  genre: string[] = ["Drama", "Fiction", "Satire","Love"];

  insert(data) {
    alert(` Name: ${data.name} Rating: ${data.rating} Genre: ${data.genre}`);
    this.movie.name = data.name;
    this.movie.rating = data.rating;
    this.movie.genre = data.genre;
    console.log(this.movie);
    this.movieservice.setmovieDetails(this.movie);
    
  }
  show(data): void {
    alert(`Book Added\nCode: ${data.code} Name: ${data.name} Author: ${data.author} Genre: ${data.genre}`);
  }
}
